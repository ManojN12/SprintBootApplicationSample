package com.example.demosteps;

import com.example.demo.SpringIntegrationTest;
import com.atlassian.ta.wiremockpactgenerator.WireMockPactGenerator;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestLogSpecification;
import io.restassured.specification.RequestSpecification;

import org.apache.commons.lang3.StringUtils;
import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Value;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.Matchers.equalTo;

public class EmployeeSteps extends SpringIntegrationTest {

	
	private static Response response;
    @Value("${app.employee.path}")
    private String basePath;

    @Value("${app.employee.uri}")
    private String baseURI;

    
    @Before
    public void setUp() {
        wireMockPact =
                WireMockPactGenerator
                        .builder("Employee-consumer", "Employee-consumer")
                        .withRequestPathWhitelist(
                        		basePath+".*"
                        )
                        .build();
        wiremock.addMockServiceRequestListener(
                wireMockPact
        );
        if (activeProfile != null && activeProfile.equalsIgnoreCase("user") ) {
            wiremock.stubFor(get(urlMatching(basePath+".*"))
                    .willReturn(
                            aResponse()
                                    .withStatus(200)
                                    .withHeader("Content-Type", "application/json")
                                    .withBodyFile("Data/CreateEmployee.json")));
        }
    }
    
  

    @When("the user create the employee$")
    public static void the_user_create_employee(){
    	RestAssured.baseURI="http://localhost:8090/";
    	    		response= RestAssured.given().contentType(ContentType.JSON).body("{\"employeename\" : \"Manoj Narayanan\"}").post();
    	}

    @Then("the status code is (\\d+)")
    public static void verifyResponseCode(int code) {
		if(response.statusCode() == code) {
			System.out.println("The status code "+code+" matches the expected code" + "Pass");
		}else {
			System.out.println("The status code "+code+" does not match the expected code" + response.statusCode());
			
		}
	}
   
}

package com.example.demo;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty"},
        glue = {"com.example.demosteps"},
        features = {"src/test/java/features"})
public class CucumberIntegrationTest extends SpringIntegrationTest{
}
